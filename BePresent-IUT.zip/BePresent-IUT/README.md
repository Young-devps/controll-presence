bepresent
This Project do the controll presence of a personnel in a company using AI and 
opencv , python, kivy, socket etc..

This have been done with python anaconda 3.6.8