CREATE TABLE Etudiant  (matricule_etud VARCHAR (16) NOT NULL,
                       Nom VARCHAR (15) NOT NULL,
                       prenom VARCHAR(25),
                       niveau integer NOT NULL,
                       specialite VARCHAR (5) NOT NULL,
                       CONSTRAINT FK_Specialite FOREIGN KEY (specialite) REFERENCES DepartementSpecialite(Code_departement),
                       CONSTRAINT PK_Etudiant PRIMARY KEY (matricule_etud));

CREATE TABLE Personnel_bepresent  (id_admin VARCHAR(16) NOT NULL,
                    	nom VARCHAR(15) NOT NULL,
                    	prenom VARCHAR(15),
                        nomUtilisateur VARCHAR(25) NOT NULL,
                        motPasse VARCHAR(30) NOT NULL,
                    	CONSTRAINT PK_Pers PRIMARY KEY (id_admin)
                    	);

CREATE TABLE Niveau  (code_niveau integer NOT NULL, 
                    	nombre_etudiant integer,
                    	nom_specialite  integer NOT NULL,
                    	CONSTRAINT PK_Reglement PRIMARY KEY (code_niveau)
                    	);

CREATE TABLE DepartementSpecialite  (Code_departement  VARCHAR (5) NOT NULL,
                      nom   VARCHAR (5) NOT NULL,        
                      niveau integer,
                      CONSTRAINT PK_Departement PRIMARY KEY (Code_departement));


CREATE TABLE Enseignant (id_enseignant VARCHAR (16) NOT NULL,
                       Nom VARCHAR (15) NOT NULL,
                       prenom VARCHAR(25),
                       nomUtilisateur VARCHAR(25),
                       motPasse VARCHAR(25) NOT NULL,
                       CONSTRAINT PK_Enseignant PRIMARY KEY (id_enseignant));


CREATE TABLE Matiere  (code_mat  VARCHAR(8) NOT NULL,
                     	nom_mat integer,
                     	id_enseignant  integer,
                     	CONSTRAINT PK_Concerner PRIMARY KEY (code_mat),
			            CONSTRAINT FK_Id_Enseignant FOREIGN KEY (id_enseignant) REFERENCES Enseignant(id_enseignant)
					  );

CREATE TABLE Salle  (	  id_salle  VARCHAR(5) NOT NULL,
                     	  id_rasberry VARCHAR(5) NOT NULL,
                          id_camera VARCHAR(5) ,
                     	  CONSTRAINT PK_Livraison PRIMARY KEY (id_salle)
                     	  );
                          
                          

create table StatPres(id_stat varchar(16) not null,
					matricule_etud VARCHAR(16) NOT NULL,
                    dateheure timestamp NOT NULL,
                    idEnseignant VARCHAR (16) NOT NULL,
                    id_salle  VARCHAR(5) NOT NULL,
		    constraint PK_ID primary key (id_stat),
                    CONSTRAINT FK_MatEtud FOREIGN KEY (matricule_etud)  REFERENCES Etudiant(matricule_etud) ON DELETE CASCADE,
                    CONSTRAINT FK_Id_Salle FOREIGN KEY (id_salle) REFERENCES Salle(id_salle),
		    CONSTRAINT FK_Id_Ens FOREIGN KEY (idEnseignant) REFERENCES Enseignant(id_enseignant)
                    );


b8:27:eb:f1:90:e0