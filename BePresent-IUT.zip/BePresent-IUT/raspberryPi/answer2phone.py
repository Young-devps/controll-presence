from controler.detector import verifier


class FaceDetection:

    def __init__(self):
        pass

    def start_detection(self):
        verifier()



def main():
    r_t = FaceDetection()
    r_t.start_detection()


if __name__ == '__main__':
    main()
