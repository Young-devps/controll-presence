# -*- encoding:utf-8 -*-
####################################################


# importation de opencv pour
import cv2
import time
import os


def assure_path_exists(path):
    dir = os.path.dirname(path)
    if not os.path.exists(dir):
        os.makedirs(dir)


# cree un pattern opencv pour la la reconnaissance source : Documentation
recognizer = cv2.face.LBPHFaceRecognizer_create()

assure_path_exists("controler/trainer/")

# lecture du fichier d'entrainement
recognizer.read('controler/trainer/trainer.yml')

# lecture du haarcascade respossable de la detection facial
cascadePath = "controler/haar/haarcascade_frontalface_default.xml"

# classification d'image. je pouvais tout aussi mettre
faceCascade = cv2.CascadeClassifier(cascadePath);

# initialisatiion de la police d'ecriture
font = cv2.FONT_HERSHEY_SIMPLEX

# Initialisation de la capture d'ecran
cam = cv2.VideoCapture(0)

# Prendre le temps de debut
debut = time.time()


def reconnaitre():
    while True:
        # lecture de la camera
        ret, im = cam.read()

        # Convertion des frames RVB en BGR/gris pour que opencv puise les traiter
        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

        # Recuperation des faces
        faces = faceCascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5)

        # pour toutes les faces
        for (x, y, w, h) in faces:

            # rectangle Identificateur de face
            cv2.rectangle(im, (x-20,y-20), (x+w+20,y+h+20), (0,255,0), 4)

            # reconnaissance de la face qui correspond a L' ID enregistrer
            Id, confidence = recognizer.predict(gray[y:y + h, x:x + w])

            if not confidence >= 50:
                name = "UnNknow"
                color = (0, 0, 255)
                stroke = 4
                cv2.putText(im, name, (x, y), font, 1, color, stroke, cv2.LINE_AA)
            elif confidence >= 50:
                name = "{0:.2f}%".format(round(100 - confidence, 2))
                color = (0, 255, 0)
                stroke = 4
                cv2.putText(im, name, (x, y), font, 1, color, stroke, cv2.LINE_AA)
                return "{0:.2f}".format(round(120 - confidence, 2)), Id
        # affichage de la video dans la fenetre opencv
        cv2.imshow('im', im)

        # arreter a si pression sur K
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break


def finReconn():
    # Arretez la camera
    cam.release()

    # Close all windows
    cv2.destroyAllWindows()


def verifier():
    try:
        os.remove("controler/Ids/currentIds.txt")
    except IOError as e:
        print("can't delete file: " + str(e))
    global debut
    fin = time.time()
    timer_counter = fin - debut
    while int(timer_counter) < 60:
        var, Id = reconnaitre()  # Id pour identifier de maniere unique chaque etudiant
        var = float(var)
        fin = time.time()
        timer_counter = fin - debut
        if (var >= 50.0):
            print("C'est Bon " + str(var))
            with open("controler/Ids/currentIds.txt", "a") as fic:
                fic.write("\n" + str(Id))
                fic.close()
        else:
            print("Non Identification ! " + str(var))



if __name__ == '__main__':
    verifier()
