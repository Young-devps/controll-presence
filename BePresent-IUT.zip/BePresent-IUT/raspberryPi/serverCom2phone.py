import socket
import threading
import time
import select
import com2server
import controler.detector as faceDetector

host = ""
port = 12803
s = None
CLIENT_IP = list()
all_connection = list()
my_lock = threading.RLock()


# create a socket(connect two computer)
def create_socket():
    try:
        global host
        global port
        global s  # socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error as msg:
        print("Socket exception error:" + str(msg))


# binding the socket and listenning for connexion
def bind_socket():
    try:
        global host
        global port
        global s
        print("Binding the port " + str(port))
        s.bind((host, port))
        s.listen(5)
        print("Bindind Done..")
    except socket.error as msg:
        print("Socket bindin Error  " + str(msg) + ".Retrying...")
        time.sleep(10)
        bind_socket()


# establish the connection with the client (socket must be listenning)
def socket_accept():
    global all_connection
    while True:
        asked_connection, wlist, xlist = select.select([s], [], [], 0.05)
        for connexion in asked_connection:
            conn, address = connexion.accept()
            all_connection.append(conn)
            CLIENT_IP.append(address)
            print("connexion has been establish with | " + str(address) + " | IP_list:" + str(CLIENT_IP[:]))
            # #print( (CLIENT_IP[0])[1] )
            # for var in CLIENT_IP:
            #     print("mac: "+ str( get_mac_address( ip=var[0] ) ) )
        try:
            client_a_lire, wlist, xlist = select.select(all_connection, [], [], 0.05)
        except select.error:
            pass
        else:
            thr_recv = threading.Thread(target=receive_command)
            thr_recv.start()
            # send_command("yoyo")


# send commad to the client/victim or a friend
def send_command(conn, msg):
    msg2send = msg.encode()
    conn.send(msg2send)


def receive_command():
    global all_connection
    with my_lock:
        for conn in all_connection:
            message = conn.recv(1024)
            msg = message.decode()
            print(msg)
            interpreter(conn, msg)


def interpreter(conn, msg):
    arr = msg.split(":")  # the message contain something like that "rasp:message"
    if (arr[0] == "phone") and (arr[1] == "detectStudentface"):
        faceDetector.verifier()
        with open("controler/Ids/currentIds.txt", "r") as fic:
            ID_lines = fic.readlines()
            fic.close()
        with open("phoneIp.txt", "w") as fic:
            fic.write(str(conn.proto))  # replace the file with new conmection parameters
            fic.write("\n" + str(conn.fileno()))
            fic.close()
        arr_detect = arr[2].split("|")
        strp = com2server.StorePresences(arr_detect[1], arr_detect[2], arr_detect[0], arr_detect[3], ID_lines)
        strp.send_a_presence()
    else:
        print("i dont know you")


def quit_gracefully(conn):
    conn.close()
    object_2_delete = all_connection.index(conn)
    del all_connection[object_2_delete]


def rasp(conn):
    send_command(conn, "thx raspberry")
    conn.close()
    object_2_delete = all_connection.index(conn)
    del all_connection[object_2_delete]


def phone(conn):
    send_command(conn, "thx phone")
    conn.close()
    object_2_delete = all_connection.index(conn)
    del all_connection[object_2_delete]


def main():
    global all_connection
    global s
    create_socket()
    bind_socket()
    socket_accept()

    for clients in all_connection:
        clients.close()
        print("Clients locked")
    s.close()


if __name__ == '__main__':
    main()