# -*- encoding:utf-8 -*-
import socket

hote = 'localhost'
port = 12800
msg_a_envoyer = b""
connexion_avec_server = None

def socket_bind_connect():
    global connexion_avec_server
    connexion_avec_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    connexion_avec_server.connect((hote, port))
    print("connexion etablite avec le port {}".format(port))


def socket_send_recv(msg):
    global connexion_avec_server
    global msg_a_envoyer

    msg_a_envoyer = "rasp:" + str(msg)
    msg_a_envoyer = msg_a_envoyer.encode()
    connexion_avec_server.send(msg_a_envoyer)

    msg_recu = connexion_avec_server.recv(1024)
    msg_a_envoyer = msg_a_envoyer.decode()
    if msg_recu.decode() == "end":
        socket_close()
    elif msg_recu.decode() != "end":
        end_msg = str(msg_recu.decode())
        arr = end_msg.split(":")
        if arr[0] == "end":
            phoneConn = None
            with open("phoneIp.txt", "r") as fic:
                phone_Proto = fic.readline()  # parameters to connect to the phone
                phone_fileno = fic.readline()
                phoneConn = socket.socket(socket.AF_INET, socket.SOCK_STREAM, int(phone_Proto), int(phone_fileno))
                fic.close()
            arr[1] = "end:" + arr[1]
            phoneConn.send(arr[1].encode())  # send the students attendances to the teacher's phone
            socket_close()


def socket_close():
    global connexion_avec_server
    connexion_avec_server.close()
    print("fermeture de la connexion avec le serveur ...")


def main():
    socket_bind_connect()
    while True:
        socket_send_recv("bepresent is automatic")

if __name__ == '__main__':
    main()